from django.shortcuts import render, redirect, get_object_or_404
from shopapp.models import Product
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Cart,CartItem,Order,OrderItem
from django.contrib.auth import login as django_login
from django.contrib.auth import authenticate
from django.contrib.auth import logout as django_logout
from django.core.exceptions import ObjectDoesNotExist

# Create your views here.

def get_discounted_price(self):
    if self.discount > 0:
        return self.price - (self.price * (self.discount / 100))
    return self.price
def checkout(request):
        cart_items = Cart.objects.filter(user=request.user)
        total_price = sum(item.product.price * item.quantity for item in cart_items)
        if request.method=="POST":
            first_name=request.POST['firstname']
            last_name=request.POST['lastname']
            product=request.POST['product']
            quantity=request.POST['quantity']
            address=request.POST['address']
            zipcode=request.POST['zipcode']
            place=request.POST['city']
            phone=request.POST['phone']
            paid_amount=request.POST['total']
            print(first_name)
            order=Order.objects.create(first_name=first_name,last_name=last_name,product=product,quantity=quantity,address=address,zipcode=zipcode,place=place,phone=phone,paid_amount=paid_amount)
           


        context = {
        "total_price":total_price,
        "cart_items":cart_items
        
        }
        return render(request, "checkout.html",context)
# def checkout(request):
#     try:
#         cart = Cart.objects.get(cart_id=_cart_id(request))
#         cart_items = CartItem.objects.filter(cart=cart, active=True)

#         total = 0
#         for cart_item in cart_items:
#             product_price = cart_item.product.get_discounted_price()
#             total += product_price * cart_item.quantity

#     except ObjectDoesNotExist:
#         cart_items = []
#         total = 0

#     return render(request, 'checkout.html', {
#         'cart_items': cart_items,
#         'total': total
#     })
# from django.db.models import Sum, F
from django.core.exceptions import ObjectDoesNotExist

def checkout(request):
    shipping_charge = 50  # Flat shipping charge

    # Fetch cart and calculate total
    try:
        cart = Cart.objects.get(cart_id=_cart_id(request))
        cart_items = CartItem.objects.filter(cart=cart, active=True)
        total = sum(cart_item.product.get_discounted_price() * cart_item.quantity for cart_item in cart_items)
    except ObjectDoesNotExist:
        cart_items = []
        total = 0

    # Add flat shipping charge to total
    total += shipping_charge

    return render(request, 'checkout.html', {
        'cart_items': cart_items,
        'total': total,
        'shipping_charge': shipping_charge
    })

   
def _cart_id(request):
    cart=request.session.session_key
    if not cart:
        cart=request.session.create()
    return cart

def add_cart(request,product_id):
    product=Product.objects.get(id=product_id)
    try:
        cart=Cart.objects.get(cart_id=_cart_id(request))
    except Cart.DoesNotExist:
        cart=Cart.objects.create(
            cart_id=_cart_id(request)
        )
        cart.save()
    try:
        cart_item=CartItem.objects.get(product=product,cart=cart)
        if cart_item.quantity < cart_item.product.stock:
            cart_item.quantity += 1
        cart_item.save()
    except CartItem.DoesNotExist:
        cart_item=CartItem.objects.create(
            product=product,
            quantity=1,
            cart=cart
        )
        cart_item.save()
    return redirect('cart:cart_detail')

# def cart_detail(request,total=0,counter=0,cart_items=None):
#     try:
#         cart=Cart.objects.get(cart_id=_cart_id(request))
#         cart_items=CartItem.objects.filter(cart=cart,active=True)
#         for cart_item in cart_items:
#             total +=(cart_item.product.price * cart_item.quantity)
#             counter +=cart_item.quantity
#     except ObjectDoesNotExist:
#         pass
#     return render(request,'cart.html',dict(cart_items=cart_items,total=total,counter=counter))



# def cart_detail(request, total=0, counter=0, cart_items=None):
#     try:
#         cart = Cart.objects.get(cart_id=_cart_id(request))
#         cart_items = CartItem.objects.filter(cart=cart, active=True)

#         for cart_item in cart_items:
#             # Use the get_discounted_price method for each product
#             product_price = cart_item.product.get_discounted_price()
#             total += product_price * cart_item.quantity
#             counter += cart_item.quantity

#     except ObjectDoesNotExist:
#         pass

#     return render(request, 'cart.html', dict(cart_items=cart_items, total=total, counter=counter))

# In your Product model, ensure you have the get_discounted_price method:
def cart_detail(request, total=0, counter=0):
    shipping_charge = 50  # Flat shipping charge
    try:
        cart = Cart.objects.get(cart_id=_cart_id(request))
        cart_items = CartItem.objects.filter(cart=cart, active=True)

        for cart_item in cart_items:
            # Use the get_discounted_price method for each product
            product_price = cart_item.product.get_discounted_price()
            total += product_price * cart_item.quantity
            counter += cart_item.quantity

    except ObjectDoesNotExist:
        # Log an error message for debugging purposes
        print(f"No cart found for cart ID: {_cart_id(request)}")
        cart_items = []

    # Add flat shipping charge to total
    total += shipping_charge

    return render(request, 'cart.html', {
        'cart_items': cart_items,
        'total': total,
        'counter': counter,
        'shipping_charge': shipping_charge,
    })



def cart_remove(request,product_id):
    cart=Cart.objects.get(cart_id=_cart_id(request))
    product=get_object_or_404(Product,id=product_id)
    cart_item=CartItem.objects.get(product=product,cart=cart)
    if cart_item.quantity > 1:
        cart_item.quantity -= 1
        cart_item.save()
    else:
        cart_item.delete()
    return redirect('cart:cart_detail')
def full_remove(request,product_id):
    cart = Cart.objects.get(cart_id=_cart_id(request))
    product = get_object_or_404(Product, id=product_id)
    cart_item = CartItem.objects.get(product=product, cart=cart)
    cart_item.delete()
    return redirect('cart:cart_detail')

# cart/views.py





def login(request):
    if request.user.is_authenticated:
        messages.warning(request,"You already logged in")
        return redirect("/")
    else:
        if request.method=="POST":
            name = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=name,password=password)

            if user is not None:
                django_login(request,user)
                messages.success(request,"Logged is successfully")
                return redirect("/base/")
            else:
                messages.error(request,"invalid username or password ")
                return redirect("/login")
    return render(request,"login.html")
       
def logout(request):
    django_logout(request)
    messages.warning(request,"please login ")
    return redirect("/base/")
from django.shortcuts import redirect
from django.contrib import messages
from .models import Order, CartItem

def placeorder(request):
    if request.method == "POST":
        # Calculate the total price based on the cart items
        cart_items = CartItem.objects.all()
        total_price = 0

        for item in cart_items:
            total_price += item.product.price * item.quantity

        if total_price == 0:
            messages.error(request, "Your cart is empty!")
            return redirect('cart')

        # Create a new order instance using form data
        new_order = Order(
            fname=request.POST.get('fname'),
            lname=request.POST.get('lname'),
            address=request.POST.get('address'),
            city=request.POST.get('city'),
            pincode=request.POST.get('pincode'),
            phone=request.POST.get('phone'),
            email=request.POST.get('email'),
            state=request.POST.get('state'),
            country=request.POST.get('country'),
            total_price=total_price  # Set the total price
        )

        try:
            # Save the order
            new_order.save()
            messages.success(request, 'Order placed successfully!')

            # Clear the cart after successful order placement
            cart_items.delete()

            # Redirect to the home page or a success page
            return redirect('/')

        except Exception as e:
            # Handle any errors during saving
            messages.error(request, f"Failed to place order: {e}")
            return redirect('/about')   # Redirect back to form on error

    # Handle non-POST requests, redirect to the order form
    return redirect('cart')   # Adjust to your actual form view

# from django.shortcuts import render, redirect
# from .models import Order

# def placeorder(request):
#     if request.method == "POST":
#         # Create a new order instance
#         new_order = Order()
#         new_order.user = request.user
#         new_order.fname = request.POST.get('fname')
#         new_order.lname = request.POST.get('lname')
#         new_order.address = request.POST.get('address')
#         new_order.city = request.POST.get('city')
#         new_order.pincode = request.POST.get('pincode')
#         new_order.phone = request.POST.get('phone')
#         new_order.email = request.POST.get('email')
#         new_order.state = request.POST.get('state')
#         new_order.country = request.POST.get('country')

#         # Save the order
#         new_order.save()

#         return redirect('/')
    
#     # Handle GET request, you may redirect to the order form or show an error
#     return redirect('order_form')  # Adjust to your actual form view
