from django.urls import path
from . import views
  # Ensure this import matches the view

app_name='cart'
urlpatterns=[
    path('', views.cart_detail, name='cart'),
    path('add/<int:product_id>/',views.add_cart,name='add_cart'),
    path('',views.cart_detail,name='cart_detail'),
    path('remove/<int:product_id>/',views.cart_remove,name='cart_remove'),
    path('full_remove/<int:product_id>/',views.full_remove,name='full_remove'),
    path('checkout',views. checkout, name="checkout"),  # This should now work correctly

   
  
    path('placeorder',views.placeorder,name="placeorder"),
  
    # dj_razorpay/urls.py


]