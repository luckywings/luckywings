$(document).ready (function () {

    $('.payWithRazorpay').click(function(e){
        e.preventDefault();

        var username =$("[name = username]").val();
        var firstname =$("[name = firstname]").val();
        var lastname =$("[name = lastname]").val();
        var address =$("[name = address]").val();
        var city =$("[name = city]").val();
        var zipcode =$("[name = zipcode]").val();

        var email =$("[name = email]").val();
        var phone =$("[name = phone]").val();

        if(username =="" || firstname =="" || lastname == "" || address == "" || city == "" || zipcode == "" || email == "" || phone == "" )
        {
         
            swal(" alert!", "All field are mandatory!", "error");
            return false; 
        }
        else
        {

            $.ajax({
                method: "GET",
                url: "/proceed-to-pay",
            
                success: function(response) {
                    console.log(response);

                }
            }) ; 
    
         

            // var options = {
            //     "key": "rzp_test_pI7M1YqbBa7kNC", // Enter the Key ID generated from the Dashboard
            //     "amount": "50000", // Amount is in currency subunits. Default currency is INR. Hence, 50000 refers to 50000 paise
            //     "currency": "INR",
            //     "name": "Acme Corp",
            //     "description": "Test Transaction",
            //     "image": "https://example.com/your_logo",
            //     "order_id": "order_IluGWxBm9U8zJ8", //This is a sample Order ID. Pass the `id` obtained in the response of Step 1
            //     "handler": function (response){
            //         alert(response.razorpay_payment_id);
            //         alert(response.razorpay_order_id);
            //         alert(response.razorpay_signature)
            //     },
            //     "prefill": {
            //         "name": "Gaurav Kumar",
            //         "email": "gaurav.kumar@example.com",
            //         "contact": "9000090000"
            //     },
            //     "notes": {
            //         "address": "Razorpay Corporate Office"
            //     },
            //     "theme": {
            //         "color": "#3399cc"
            //     }
            // };
            // var rzp1 = new Razorpay(options);
            // rzp1.open();
                  

        }
        if (typeof jQuery !== 'undefined') {
            console.log("jQuery is loaded.");
        } else {
            console.log("jQuery is not loaded.");
        }
        

     
       



    })

})