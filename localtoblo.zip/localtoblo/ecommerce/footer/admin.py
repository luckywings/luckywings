
from django.contrib import admin
from .models import StarRating

# Define how the review model is displayed in the admin


class ReviewAdmin(admin.ModelAdmin):
    list_display = ('fname', 'rating', 'created_at')  # Fields to display in the admin list
    search_fields = ('fname', 'message')  # Searchable fields
    list_filter = ('rating', 'created_at')  # Filterable fields

# Register the Review model with the customized admin
admin.site.register(StarRating, ReviewAdmin)

