from django.shortcuts import render, redirect

 # Import the ReviewForm class
from django.utils import timezone


from .models import StarRating
 # Assuming you have a form for the review

from django.shortcuts import render

def term(request):
    return render(request, 'term.html')

def privacy(request):
    return render(request, 'privacy.html')

def Refund(request):
    return render(request, 'Refund.html')

def Return(request):
    return render(request, 'Return.html')

def Shipping(request):
    return render(request, 'Shipping.html')

def placereview(request):
    if request.method =='POST':
        newreview=StarRating()
        newreview.user=request.user
        newreview.fname =request.POST.get('fname')
        newreview.rating =request.POST.get('rating')
        newreview.message =request.POST.get('message')
        newreview.save()
    return redirect('/')

