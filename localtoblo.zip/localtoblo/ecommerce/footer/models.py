from django.db import models

class StarRating(models.Model):

    fname = models.CharField(max_length=100, default='Anonymous')

    rating = models.IntegerField(choices=[(i, str(i)) for i in range(1, 6)], default=1)  # Choices from 1 to 5
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.fname} ({self.rating} stars)'

