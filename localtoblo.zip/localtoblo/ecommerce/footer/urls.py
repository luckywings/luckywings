from django.urls import path
from .import views

app_name= 'footer'
urlpatterns=[
  # Thank you page route
    path('placereview',views.placereview,name="placereview"),
     path('term', views.term, name='term'),
     path('privacy', views.privacy, name='privacy'),
      path('Refund', views.Refund, name='Refund'),
       path('Return', views.Return, name='Return'),
      path('Shipping', views.Shipping, name='Shipping'),
]

